# CS106 Integrated Studio 2 
  COVID-19 Newzealand 

This is a Yoobee College CS106 Software Engineering conceptual project that is built in C++ with QT, to allow citizens of New Zealand to access their Covid Vaccination , Login  and test details easily .

#QT cerator 10.0.3 (Community)

#SQLite Manager (For Database)  
https://sqlabs.com/download/SQLiteManager64bitSetup.exe

Import Project in D drive beacuse of SQLITE Path ("D:/CS106_A2_Project/mycovidnz.sqlite")

